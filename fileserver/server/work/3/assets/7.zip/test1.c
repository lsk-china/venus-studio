#include "test1.h"
program
print("宏定义NB");
exit
