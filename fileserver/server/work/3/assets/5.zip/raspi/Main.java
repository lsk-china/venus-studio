import java.net.*;
import java.io.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocket ss = null;
		try {
			ss = new ServerSocket(10001);
			String root = "server";
			while(true) {
				Socket client = ss.accept();
				System.out.println(client);
				InputStream is = client.getInputStream();
				String request = "";
				byte[] reqBytes = new byte[1024];
				int length = 0;
				if((length = is.read(reqBytes)) > 0) {
					request = new String(reqBytes,0,length); 
				}
                                System.out.println(request);
				String head = request.split("\n")[0];
				String urla[] = head.split("\\s");
				System.out.println(urla);
				System.out.println(urla.length);
				if(urla.length < 2){
					client.close();
					continue;
				}
				String url = urla[1];
				System.out.println(url);
                                if(url == null || url.equals("/"))
					url = "/index.html";
				File target = new File(root+url);
				if(target.exists()) {
                                        String type = "";
                                        if(url.endsWith(".html"))
                                        	type = "Content-Type: text/html\n";
					StringBuilder responseString = new StringBuilder();
					responseString.append("HTTP/1.1 200 OK\n").
                                        append(type).
					append("\r\n");
					OutputStream os = client.getOutputStream();
			 		os.write(responseString.toString().getBytes());
			                FileInputStream fis = new FileInputStream(target);
                                        byte[] buffer = new byte[1024];
					int length2 = 0;
					while((length2 = fis.read(buffer , 0 , 1024)) != -1){
						os.write(buffer,0,length2);
					}
					fis.close();
					os.close();
					client.close();
					continue;
				}
				StringBuilder responseString = new StringBuilder();
				responseString.append("HTTP/1.1 404 Not Found\n").
				append("Content-Type: text/html\n").
				append("\r\n").append("<html><body><h1>404</h1><br>File Not Found</body></html>");
				OutputStream os = client.getOutputStream();
				os.write(responseString.toString().getBytes());
				os.close();
				client.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if (ss != null) {
				try {
					ss.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

}
