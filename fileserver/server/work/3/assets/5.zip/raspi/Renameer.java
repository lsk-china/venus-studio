import java.io.*;
public class Renameer{
	public static void main(String[] args) throws Exception{
		if(args.length < 2){
			System.exit(1);
		}
		String source = args[0];
		String target = args[1];
		File sourceFile = new File(source);
                File targetFile = new File(target);
		if(!sourceFile.exists()){
			System.exit(1);
		} 
                if(targetFile.exists()){
                        System.exit(1);
                }
		sourceFile.renameTo(targetFile);
	}
}

