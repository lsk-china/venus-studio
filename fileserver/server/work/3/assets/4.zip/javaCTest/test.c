#include <stdio.h>
#include "JavaCallC.h"

JNIEXPORT void JNICALL Java_JavaCallC_test(JNIEnv* env, jobject jbt)
{
	printf("Hello world!");
}
