public class JavaCallC{
	static{
		System.out.println(System.getProperty("java.library.path"));
		System.loadLibrary("JavaCallC");
	}

	public native void test();

	public static void main(String[] args){
		JavaCallC test = new JavaCallC();
		test.test();
	}
}


