import java.net.*;
import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocket ss = null;
		try {
			ss = new ServerSocket(10001);
			
                        
			while(true) {
				Socket client = ss.accept();
				System.out.println(client);
				new Thread(new Procresser(client)).start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if (ss != null) {
				try {
					ss.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

}
class Procresser implements Runnable{
		private Socket client;
		private InetAddress lastRequest;
		private String root = "server";
		public Procresser(Socket socket){
					this.client = socket;
					try{
						this.lastRequest = InetAddress.getByName("127.0.0.1");
					}catch(Exception e){
						e.printStackTrace();
					}
		}
		@Override
		public void run(){
				try{
					InputStream is = client.getInputStream();
				String request = "";
				byte[] reqBytes = new byte[1024];
				int length = 0;
				if((length = is.read(reqBytes)) > 0) {
					request = new String(reqBytes,0,length); 
				}
                                System.out.println(request);
				String head = request.split("\n")[0];
				String urla[] = head.split("\\s");
				System.out.println(urla);
				System.out.println(urla.length);
				if(urla.length < 2){
					client.close();
				}
				String url = urla[1];
				System.out.println(url);
                if(url == null || url.equals("/"))
					url = "/index.html";
                                
                                //if(!client.getInetAddress().equals(InetAddress.getByName("192.168.31.113")) || !client.getInetAddress().equals(lastRequest)){
				if(false){				
					 System.out.println("Accpet? true/false");
                                     Scanner scanner = new Scanner(System.in);
                                     boolean accept = scanner.nextBoolean();
									 if(!accept){ 
                                        StringBuilder responseString = new StringBuilder();
                                        responseString.append("HTTP/1.1 403 Forbidden\n").
                                        append("Content-Type: text/html\n").
                                        append("\r\n").append("<html><body><h1>403</h1><br>Forbidden</body></html>");
                                        OutputStream os = client.getOutputStream();
                                        os.write(responseString.toString().getBytes());
                                        os.close();
                                        client.close();
								     }
                                }
				File target = new File(root+url);
				if(target.exists()) {
                                        String type = "";
                                        if(url.endsWith(".html"))
                                        	type = "Content-Type: text/html\n";
					StringBuilder responseString = new StringBuilder();
					responseString.append("HTTP/1.1 200 OK\n").
                                        append(type).
					append("\r\n");
					OutputStream os = client.getOutputStream();
			 		os.write(responseString.toString().getBytes());
			                FileInputStream fis = new FileInputStream(target);
                                        byte[] buffer = new byte[1024];
					int length2 = 0;
					while((length2 = fis.read(buffer , 0 , 1024)) != -1){
						os.write(buffer,0,length2);
					}
   
					fis.close();
					os.close();
                                        lastRequest = client.getInetAddress();
					client.close();
				}
				StringBuilder responseString = new StringBuilder();
				responseString.append("HTTP/1.1 404 Not Found\n").
				append("Content-Type: text/html\n").
				append("\r\n").append("<html><body><h1>404</h1><br>File Not Found</body></html>");
				OutputStream os = client.getOutputStream();
				os.write(responseString.toString().getBytes());
				os.close();
                                lastRequest = client.getInetAddress();
				client.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
}
