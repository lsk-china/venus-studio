CREATE TABLE sms.students (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(50) NOT NULL,
  grade varchar(255) NOT NULL,
  clazz varchar(255) NOT NULL,
  age int(11) NOT NULL,
  sex varchar(255) NOT NULL,
  image varchar(255) NOT NULL DEFAULT 'noface.png',
  PRIMARY KEY (id)
)
ENGINE = INNODB
AUTO_INCREMENT = 5
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;