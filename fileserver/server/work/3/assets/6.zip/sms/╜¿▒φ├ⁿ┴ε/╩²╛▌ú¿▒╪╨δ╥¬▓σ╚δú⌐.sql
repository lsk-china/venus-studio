insert into persons(name,password,role) values("admin","123456","admin");
insert into persons(name,password,role) values("xiaoming","234567","student");
insert into students(name,grade,clazz,age,sex) values("xiaoming","1","1","10","boy");
