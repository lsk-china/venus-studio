package com.lsk.sms.security;

import com.lsk.sms.dao.PersonDao;
import com.lsk.sms.model.Person;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;

@Component("userDetailsService")
@Slf4j
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private PersonDao personDao;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
        Person person = personDao.queryPersonByName(name);
        log.info(name);
        if(person == null){
            log.warn("not found!");
            throw new UsernameNotFoundException("Person " + name + " was not found in db");
        }
        log.info(person.getPassword());
        Collection<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(person.getRole());
        grantedAuthorities.add(grantedAuthority);
        String password = passwordEncoder.encode(person.getPassword());
        log.info(person.getRole());
        return new User(name,password,grantedAuthorities);
    }
}
