package com.lsk.sms.security;

public enum Roles {

    ADMIN("admin",2),Student("student",1);

    private int p;
    private String name;
    Roles(String name,int p){
        this.name = name;
        this.p = p;
    }
    public int getP() {
        return this.p;
    }

}
