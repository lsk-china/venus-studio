package com.lsk.sms.dao;

import com.lsk.sms.model.Student;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StudentDao {
    @Select("select * from students where name=#{name}")
    public Student queryStudentByName(@Param("name") String name);

    @Select("select * from students where id=#{id}")
    public Student queryStudentById(@Param("id") Integer id);

    @Insert("insert into students(name,grade,clazz,age,sex) values(#{name},#{grade},#{clazz},#{age},#{sex})")
    public void addStudent(Student student);

    @Update("update students set name=#{name},grade=#{grade},clazz=#{clazz},grade=#{grade},age=#{age},sex=#{sex} where id=#{id}")
    public void updateStudentById(Student student);

    @Delete("delete from students where id=#{id}")
    public void deleteStudentById(@Param("id") Integer id);

    @Select("select * from students")
    public List<Student> queryAllStudents();

    @Update("update students set image=#{image} where id=#{id}")
    public void updateImageById(@Param("image") String image,@Param("id") Integer id);
}

