package com.lsk.sms.aspect;

import com.lsk.sms.security.RoleUtils;
import com.lsk.sms.security.Roles;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;

@Aspect
@Slf4j
@Component
public class StudentAspect {
    @Around("@annotation(com.lsk.sms.aspect.annotation.Student)")
    public Object around(ProceedingJoinPoint pjp) throws Throwable{
//      log.info("AdminAspect");
//      return pjp.proceed();
        HttpServletResponse resp = (HttpServletResponse) pjp.getArgs()[0];
        if(RoleUtils.getRole(SecurityContextHolder.getContext().getAuthentication().getAuthorities()) == Roles.Student){
            return pjp.proceed();
        }
        resp.sendRedirect("/permission_dined.html");
        return new ModelAndView();
    }
}
