package com.lsk.sms.aspect;

import com.lsk.sms.aspect.annotation.UserName;
import com.lsk.sms.security.RoleUtils;
import com.lsk.sms.security.Roles;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Aspect
@Slf4j
@Component
public class UserNameAspect {
    @Around("@annotation(com.lsk.sms.aspect.annotation.UserName)")
    public Object around(ProceedingJoinPoint pjp) throws Throwable{
        Object[] params = pjp.getArgs();
        String name = (String)params[2];
        log.info(name);
        if(SecurityContextHolder.getContext().getAuthentication().getName().equals(name) || RoleUtils.hasRole(RoleUtils.getRole(SecurityContextHolder.getContext().getAuthentication().getAuthorities()),Roles.ADMIN)){
            return pjp.proceed();
        }else{
            return "Permission Dined";
        }
    }
}
