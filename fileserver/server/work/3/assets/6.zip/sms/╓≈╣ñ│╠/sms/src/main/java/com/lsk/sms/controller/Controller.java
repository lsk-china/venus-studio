package com.lsk.sms.controller;

import com.lsk.sms.aspect.annotation.Admin;
import com.lsk.sms.aspect.annotation.Student;
import com.lsk.sms.aspect.annotation.UserName;
import com.lsk.sms.dao.PersonDao;
import com.lsk.sms.dao.StudentDao;
import com.lsk.sms.model.Person;
import com.lsk.sms.security.RoleUtils;
import com.lsk.sms.security.Roles;
import com.lsk.sms.security.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.List;

@RestController
@Slf4j
public class Controller {

    @Autowired
    private StudentDao studentDao;

    @Autowired
    private PersonDao personDao;

    @GetMapping("/")
    public void index(HttpServletResponse resp) throws IOException {
        if(RoleUtils.getRole(SecurityContextHolder.getContext().getAuthentication().getAuthorities()) == Roles.ADMIN){
            resp.sendRedirect("/admin");
        }else{
            resp.sendRedirect("/student");
        }
    }

    @GetMapping("admin")
    @Admin
    public ModelAndView admin(HttpServletResponse resp,ModelAndView mav){
        List<com.lsk.sms.model.Student> students = studentDao.queryAllStudents();
        mav.addObject("students",students);
        mav.setViewName("admin.html");
        return mav;
    }
    @GetMapping("student")
    @Student
    public ModelAndView student(HttpServletResponse resp,ModelAndView mav){
        com.lsk.sms.model.Student student = studentDao.queryStudentByName(SecurityUtils.getName());
        mav.addObject("student",student);
        mav.addObject("image","http://localhost:10001/sms/img/"+student.getImage());
        mav.setViewName("student.html");
        return mav;
    }
    @GetMapping("addstudent")
    @Admin
    public void addStudent(HttpServletResponse resp, @RequestParam("name") String name, @RequestParam("password") String password, @RequestParam("age") Integer age, @RequestParam("sex") String sex, @RequestParam("grade") String grade, @RequestParam("clazz") String clazz) throws IOException {
        Person person = new Person();
        person.setName(name);
        person.setPassword(password);
        person.setRole(Roles.Student.name());
        com.lsk.sms.model.Student student = new com.lsk.sms.model.Student();
        student.setAge(age);
        student.setClazz(clazz);
        student.setGrade(grade);
        student.setSex(sex);
        student.setName(name);
        personDao.addPerson(person);
        studentDao.addStudent(student);
        resp.sendRedirect("/admin");
    }
    @GetMapping("removestudent")
    @Admin
    public void removeStudent(HttpServletResponse resp,@RequestParam("name") String name) throws IOException {
        com.lsk.sms.model.Student student = studentDao.queryStudentByName(name);
        Integer studentId = student.getId();
        Person person = personDao.queryPersonByName(name);
        Integer personId = person.getId();
        studentDao.deleteStudentById(studentId);
        personDao.deletePersonById(personId);
        resp.sendRedirect("/admin");
    }
    @GetMapping("updatestudent")
    @Admin
    public void updateStudent(HttpServletResponse resp,HttpServletRequest req,@RequestParam("name") String name,@RequestParam("password") String password,@RequestParam("age") Integer age,@RequestParam("grade") String grade,@RequestParam("clazz") String clazz) throws IOException {
        Person person = personDao.queryPersonByName(name);
        com.lsk.sms.model.Student student = studentDao.queryStudentByName(name);
        String destPassword = password == null || password.equals("") ? person.getPassword() : password;
        String destGrade = grade == null || grade.equals("") ? student.getGrade() : grade;
        Integer destAge = age == null ? student.getAge() : age;
        String destClazz = clazz == null || clazz.equals("") ? student.getClazz() : clazz;
        Person destPerson = new Person(person.getId(),name,destPassword,person.getRole());
        com.lsk.sms.model.Student destStudent = new com.lsk.sms.model.Student(student.getId(),name,destGrade,destClazz,destAge,student.getSex(),student.getImage());
        personDao.updatePersonById(destPerson);
        studentDao.updateStudentById(destStudent);
        resp.sendRedirect("/admin");
    }

    @GetMapping("updatestudent_s")
    @Student
    public void updateStudentForStudent(HttpServletResponse resp,HttpServletRequest req,@RequestParam("password") String password) throws IOException {
        String name = SecurityContextHolder.getContext().getAuthentication().getName();
        Person person = personDao.queryPersonByName(name);
        Person destPerson = new Person(person.getId(),name,password,person.getRole());
        personDao.updatePersonById(destPerson);
        resp.sendRedirect("/student");
    }
//    @GetMapping("updateimage")
//    @Student
//    public void updateImage(@RequestParam("image") String image){
//        String name = SecurityUtils.getName();
//        Integer id = studentDao.queryStudentByName(name).getId();
//        studentDao.updateImageById(image,id);
//    }
    @PostMapping("updateimage")

    public void updateimage(HttpServletResponse resp,@RequestParam("file") MultipartFile file) throws IOException {
        if(file == null){
            Cookie cookie = new Cookie("reason","请选择一个文件。");
            resp.addCookie(cookie);
            resp.sendRedirect("/student");
            return;
        }
        String fileName = file.getOriginalFilename();
        String path = "D://java/server/sms/img/";
        log.info(path+fileName);
        File destFile = new File(path+fileName);
        try{
            file.transferTo(destFile);
        }catch(Exception e){
            Cookie cookie = new Cookie("reason","上传失败。");
            resp.addCookie(cookie);
            resp.sendRedirect("/student");
            return;
        }
        String name = SecurityUtils.getName();
        Integer id = studentDao.queryStudentByName(name).getId();
        studentDao.updateImageById(fileName,id);
        resp.sendRedirect("/student");
    }

}
