package com.lsk.sms.security;

import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Iterator;

public class RoleUtils {
    public static boolean hasRole(Roles role,Roles tarRole){
        return tarRole.getP() <= role.getP();
    }
    public static Roles getRole(Collection<? extends GrantedAuthority> role){
        String strRole = "";
        for (Iterator<? extends GrantedAuthority> it = role.iterator(); it.hasNext(); ) {
            GrantedAuthority grantedAuthority = it.next();
            strRole = grantedAuthority.getAuthority();

        }
        switch(strRole){
            case "admin":
                return Roles.ADMIN;
            case "student":
                return Roles.Student;
        }
        throw new RuntimeException("Unknow role :"+role);
    }
}
