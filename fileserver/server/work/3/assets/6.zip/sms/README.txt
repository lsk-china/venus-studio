这个程序需要安装：
Mysql Server
JDK 1.8.0 （需要配置环境变量）
Maven （需要配置环境变量）
准备：
在Mysql中创建一个叫sms的数据库，然后执行建表命令文件夹里的三个SQL脚本。
在D盘根目录下创建java目录，并把静态服务器文件夹下的所有东西拷贝到那里。
把主工程/sms/src/main/resources/application.properties文件中的”你的Mysql用户名、密码“修改成你的Mysql用户名和密码
运行方法：
命令行先cd到D盘的java目录下，输入 java Main
再cd到主工程下面的sms，输入下面的命令：
mvn package
cd target
java -jar 
如果上面的命令都没有报错，就可以打开浏览器，地址栏输入http://localhost:8080/ 即可看到效果
如果出错了，群里问我